﻿Druel Damien



Doit contenir :
- ce que vous avez fait.
	       
- ce que vous n'avez pas fait (et pourquoi).

	       - difficultés rencontrées.

               - commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 



- Question 5.
=> methode draw() : glDrawArrays(GL_TRIANGLES,0,6);

- Question 8.
Il faut les tracer dans l'ordre : 0 3 2  5 1 4

- Question 14 : 
glDrawArrays(GL_TRIANGLE_STRIP,0,9) relie les sommets consécutifs qui ne sont pas relié entre eux 


Fait :

Question 1-15 (sauf couleurs)


Pas fait :
Bloqué question 16 je n'arrive pas a faire l'algorithme.
J'ai perdu 2h en faisant le TP de l'année dernière et je n'ai pas réussi a ratrapper mon retard chez moi.
